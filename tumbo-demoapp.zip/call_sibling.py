def func(self):
	return self.siblings.sibling_A(self)