def func(self):
	return "Running Init"