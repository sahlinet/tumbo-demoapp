def func(self):
	return "sibling_A says Hello"